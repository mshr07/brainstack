"""Core configuration package."""

